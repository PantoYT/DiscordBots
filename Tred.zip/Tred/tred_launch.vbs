Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "python main.py", 0, False
Set WshShell = Nothing
